clc, clear

a=-4.5; b=-3.5;

k=0.01; %koeff relaksacii

x=(a+b)/2;
fprintf('Metod Jakobi\n************\n');
for (i=1:1:6)
fprintf('ITERATION %i',i);
temp1=x+k*fun(x)
%temp2=abs(temp1-x);
x=temp1;
fprintf('\n*********************\n');
end