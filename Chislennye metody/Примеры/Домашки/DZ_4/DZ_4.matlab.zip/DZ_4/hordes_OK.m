clc, clear

a=-4.5; b=-3.5;

fprintf('Metod Hordes\n************\n');
for (i=1:1:6)
fprintf('ITERATION %i',i);
x0=b-((b-a)/(fun(b)-fun(a)))*fun(b)
if ((fun(x0)*fun(a))<=0)
  fprintf('Vypolnjaetsja');
b=x0
else
  fprintf('Ne vypolnjaetsja');
a=x0
end
fx0=fun(x0)
fa=fun(a)
fprintf('\n*********************\n');
end