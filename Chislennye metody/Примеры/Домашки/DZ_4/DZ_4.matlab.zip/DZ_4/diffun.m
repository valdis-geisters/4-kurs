function F = diffun(x)
% x(2*sin(x)+x*cos(x)) moja proizvodnaja
F = x(2*sin(x)+x*cos(x));
end