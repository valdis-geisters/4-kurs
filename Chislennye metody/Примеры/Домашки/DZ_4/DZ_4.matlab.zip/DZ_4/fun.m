function F = fun(x)
%F = (x^2) * sin(x)-11;
F = x^2 * sin(x) -11;
end