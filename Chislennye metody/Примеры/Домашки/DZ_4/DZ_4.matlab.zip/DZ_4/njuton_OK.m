clc, clear

a=-4.5; b=-3.5;

fprintf('Metod Njutona\n*******************\n');
xi=(a+b)/2
fprintf('\n********************\n');
for (i=1:1:6)
fprintf('ITERATION %i',i);
xii=xi-((fun(xi))/(diffun(xi)))
xi=xii;
fprintf('\n*********************\n');
end