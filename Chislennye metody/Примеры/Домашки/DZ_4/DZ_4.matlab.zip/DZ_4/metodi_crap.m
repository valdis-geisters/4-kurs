%x^2*sin(x)
%//BISEKTION
a=0; b=pi;

fprintf('BISEKCIJA');
for (i=1:1:6)
fprintf('\niteration %i',i);
x0=(a+b)/2
if ((fun(x0)*fun(a))<=0)
  fprintf('Vypolnjaetsja');
b=x0
else
  fprintf('Ne vypolnjaetsja');
a=x0
end
fx0=fun(x0)
fa=fun(a)
fprintf('\n*********************\n');
end

%//HORDE
%a=0; b=pi;
% 
% for (i=1:1:6)
% fprintf('%i',i);
% x0=b-((b-a)/(fun(b)-fun(a)))*fun(b)
% if ((fun(x0)*fun(a))<=0)
%   fprintf('Vypolnjaetsja');
% b=x0
% else
%   fprintf('Ne vypolnjaetsja');
% a=x0
% end
% fx0=fun(x0)
% fa=fun(a)
% fprintf('*********************');
% end
	
% %//NJUTON
% a=0; b=pi;
% xi=(a+b)/2
% for (i=1:1:6)
% fprintf('**********%i**********',i);
% xii=xi-((fun(xi))/(diffun(xi)))
% xi=xii;
% fprintf('*********************');
% end

% 
% 
% %//JAKOBI
% x^2*sin(x)'
% 
% %???????? ????????????
% (1-6*x*cot(3*x))*csc(3*x)^2+1,x=0.5500
% 
% %???????? ???????????? ? ????????????? ??????????
% (k=-0.1)
% 1-0.1*((1-6*x*cot(3*x))*csc(3*x)^2),x=0.5500
% : a=0.1; b=1; k=-0.01;
% x=(a+b)/2;
% 
% for (i=1:1:6)
% i
% temp1=x+k*fun(x)
% temp2=abs(temp1-x);
% x=temp1;
%end
